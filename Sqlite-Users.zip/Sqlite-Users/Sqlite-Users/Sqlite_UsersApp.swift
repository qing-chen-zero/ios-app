//
//  Sqlite_UsersApp.swift
//  Sqlite-Users
//
//  Created by Qingchen on 2022/4/18.
//

import SwiftUI

@main
struct Sqlite_UsersApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
