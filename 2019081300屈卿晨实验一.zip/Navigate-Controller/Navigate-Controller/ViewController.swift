//
//  ViewController.swift
//  Navigate-Controller
//
//  Created by Qingchen on 2022/4/13.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

