//
//  ContentView.swift
//  test01
//
//  Created by Qingchen on 2022/4/12.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView { // 使用NavigationView 实现界面跳转
            //使用跳转链接实现点击跳转
            NavigationLink("快点击我完成跳转！", destination:NavigateTo())
                .padding(10)
                .font(.system(size: 20))
                .background(.red)
                .foregroundColor(.white)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
