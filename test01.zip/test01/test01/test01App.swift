//
//  test01App.swift
//  test01
//
//  Created by Qingchen on 2022/4/12.
//

import SwiftUI

@main
struct test01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
