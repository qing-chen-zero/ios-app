//
//  NavigateTo.swift
//  test01
//
//  Created by Qingchen on 2022/4/12.
//

import SwiftUI

struct NavigateTo: View {
    var body: some View {
        //跳转之后的界面
        Text("恭喜您，这是您跳转之后的界面！")
    }
}

struct NavigateTo_Previews: PreviewProvider {
    static var previews: some View {
        NavigateTo()
    }
}
